import joblib
import pandas as pd

# Modelni yuklash
loaded_model = joblib.load("linear_regression_model.pkl")
print("Model yuklandi ✅")

# Yangi ma'lumot (x = 26)
new_data = pd.DataFrame([[26]], columns=['x1'])

# Bashorat
prediction = loaded_model.predict(new_data)

print("Bashorat qilingan qiymat:", prediction[0])
