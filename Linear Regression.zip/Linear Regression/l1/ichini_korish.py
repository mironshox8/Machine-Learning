import joblib

# Modelni yuklash
model = joblib.load("linear_regression_model.pkl")

# Parametrlar
print("=== Linear Regression parametrlari ===")
print("Coefficient (weight):", model.coef_)
print("Intercept (bias):", model.intercept_)
