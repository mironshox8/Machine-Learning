import numpy as np
import pandas as pd

np.random.seed(42)

x1 = np.random.randint(20, 100, 100)
x2 = np.random.randint(30, 120, 100)
x3 = np.random.randint(10, 80, 100)

# Linear bog‘lanish + shovqin
y = 2.5 * x1 + 1.8 * x2 + 3.2 * x3 + np.random.normal(0, 50, 100)

data = {
    "x1": x1,
    "x2": x2,
    "x3": x3,
    "price": y
}

df = pd.DataFrame(data)
df.to_csv("linear_dataset1.csv", index=False)

print("Linear Regression dataset yaratildi ✅")
