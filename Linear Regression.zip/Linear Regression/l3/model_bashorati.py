import joblib

loaded_model = joblib.load("linear_regression_model.pkl")
print("Model yuklandi ✅")
new_data = [[26,61,33]]
prediction = loaded_model.predict(new_data)

print("Bashorat qilingan qiymat:", prediction[0])
